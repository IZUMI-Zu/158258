const popup_js = function pop(x) {
    alert(x)
}